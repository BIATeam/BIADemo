# Example of functionnalities in projects

This files list the functionnalities use in different project build with the framework V3.
**Every developer should contribut to this file**

## Connector Usage:
Open this file to see connector usage: [ConnectorsUsage.xls ](http://nateamwork.labinal.snecma/sep/is/PDMnDM/DM/Documents/300_ARCHI_INFRA/330_APPLICATION/ConnectorsUsage.xlsx).


## Scheduled task (Tache planifiée)
**Windows Service / WorkerService**
* SkillPower
* JobMonitor

## Image computing(Traitement d'image)

## Data loading(Chargement de données)
**Load DB to DB with SSIS (Chargement d'une BDD vers une autre via SSIS)**
* ADPConnector

**Upload files**
* iDo => But produce error 401 in other project
* ESNAuto Line (Angular\src\app\features\extremity-configurations\components\extremity-configuration-attachment-new-dialog)
* ChangeNote (Angular\src\app\features\physical-harnesses\components\physical-harness-form)

## BackEnd
**Use SQL view (Utilisation Vue SQL)**
* SkillPower

## FrontEnd
(moved to EXAMPLE_IN_PROJECTS.md in Angular folder)


## Manipulation de document Document
**Creation/Lecture PDF avec PDF Sharp**
* SkillPower

