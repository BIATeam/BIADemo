export const FRAMEWORK_VERSION = '3.4.0';
