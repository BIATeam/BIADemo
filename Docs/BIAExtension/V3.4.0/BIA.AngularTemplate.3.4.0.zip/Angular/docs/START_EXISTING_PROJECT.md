



Clone the project
- In Angular project do  npm install
- do npm start