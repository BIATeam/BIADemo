# New Project
This document explains how to start an existing  project.   

* Clone the project
* In Angular project do  npm install
* do npm start