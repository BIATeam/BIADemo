export interface Role {
  id: number;
  labelEn: string;
  labelFr: string;
  labelEs: string;
  isDefault: boolean;
}
