export interface BiaNavigation {
  path?: string[];
  labelKey: string;
  children?: BiaNavigation[];
  permissions?: string[];
}
