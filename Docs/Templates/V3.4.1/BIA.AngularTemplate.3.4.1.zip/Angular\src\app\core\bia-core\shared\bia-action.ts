import { createAction } from '@ngrx/store';

export const biaSuccessWaitRefreshSignalR = createAction('[Bia] Success the refresh of the list will be done by signalR.');
