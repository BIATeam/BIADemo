### [3.3.3] (2021-06-25)
* Universal Mode for CRUD.
### [3.3.2] (2021-05-28)
* Possibility for the user to choice his role.
* Click on site open manage member.
* Member is a children of site with related service and breadcrumb.
* Adding the Calc mode for CRUD.
### [3.3.1] (2021-03-31)
### [3.3.0] (2021-01-15)
*  Date bug fix
*  Matomo integration
*  Crud generation support complexe name (like plane-type)
*  Add choice of the site for Admin
### [3.2.2] (2020-11-24)
*  Color by env.
### [3.2.0] (2020-06-26)
*  angular 9.1.12
### [3.1.1] (2020-06-26)
*  Bug Fix
### [3.1.0] (2020-05-04)
*  views
### [3.0.0] (2020-07-02)
*  angular 8.2.14
