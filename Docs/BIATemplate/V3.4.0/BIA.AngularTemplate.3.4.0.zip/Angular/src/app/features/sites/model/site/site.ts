import { BaseDto } from 'src/app/shared/bia-shared/model/base-dto';

export interface Site extends BaseDto {
  title: string;
}
