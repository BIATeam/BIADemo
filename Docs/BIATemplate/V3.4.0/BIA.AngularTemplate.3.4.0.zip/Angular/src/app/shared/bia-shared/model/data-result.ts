export interface DataResult<T> {
  data: T;
  totalCount: number;
}
