export interface DefaultView {
  id: number;
  tableId: string;
  isDefault: boolean;
}
